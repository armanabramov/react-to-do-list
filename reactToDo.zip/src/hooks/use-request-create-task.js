import { useEffect } from 'react';

export const useRequestCreateTask = () => {
	useEffect(() => {
		fetch('http://localhost:3001/todos', {
			method: 'GET',
			headers: {
				'Content-Type': 'application/json',
			},
			body: JSON.stringify({ title: 'new task', completed: false }),
		}).then((response) => {
			if (!response.ok) {
				throw new Error(`Ошибка сети: ${response.status}`);
			}
			return response.json();
		});
	}, []);
};
