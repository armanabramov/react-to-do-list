import { useState, useRef, useEffect } from 'react';
import styles from './CreateTaskButton.module.css';

export default function CreateTaskButton() {
	const [isOpen, setIsOpen] = useState(false);
	const [taskText, setTaskText] = useState('');
	const [tasks, setTasks] = useState([]);
	const inputRef = useRef(null);

	useEffect(() => {
		if (!isOpen) return;
		// фокус на input при открытии
		setTimeout(() => inputRef.current?.focus(), 0);

		// закрыть по Escape
		const onKeyDown = (e) => {
			if (e.key === 'Escape') setIsOpen(false);
		};
		document.addEventListener('keydown', onKeyDown);
		return () => document.removeEventListener('keydown', onKeyDown);
	}, [isOpen]);

	const openModal = () => setIsOpen(true);
	const closeModal = () => {
		setIsOpen(false);
		setTaskText('');
	};

	// если кликнули по оверлею (не по модалке) — закрываем
	const onOverlayMouseDown = (e) => {
		if (e.target === e.currentTarget) closeModal();
	};

	const onSubmit = (e) => {
		e.preventDefault();
		const text = taskText.trim();
		if (!text) return;
		const newTask = { id: Date.now(), text };
		setTasks((prev) => [newTask, ...prev]);
		closeModal();
		// здесь позже можно добавить POST на json-server
	};

	return (
		<>
			<button type="button" className={styles.createTaskButton} onClick={openModal}>
				<span className={styles.createTaskButton__icon} aria-hidden></span>
				Create Task
			</button>

			{isOpen && (
				<div
					className={styles.modal__wrapper}
					onMouseDown={onOverlayMouseDown}
					role="dialog"
					aria-modal="true"
				>
					<div
						className={styles.modal}
						// предотвращаем всплытие клика на оверлей, если клик в самой модалке
						onMouseDown={(e) => e.stopPropagation()}
					>
						<div className={styles.modal__content}>
							<h2 className={styles.modal__title}>Новая задача</h2>

							<form onSubmit={onSubmit}>
								<input
									ref={inputRef}
									className={styles.modal__input}
									value={taskText}
									onChange={(e) => setTaskText(e.target.value)}
									placeholder="Введите текст задачи"
								/>

								<div className={styles.modal__actions}>
									<button
										type="button"
										className={styles.modal__btn}
										onClick={closeModal}
									>
										Cancel
									</button>
									<button
										type="submit"
										className={`${styles.modal__btn} ${styles.modal__btn_primary}`}
									>
										Create
									</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			)}

			<ul className={styles.taskList}>
				{tasks.map((t) => (
					<li key={t.id} className={styles.taskList__item}>
						{t.text}
					</li>
				))}
			</ul>
		</>
	);
}
