import styles from './ToDoItemActionButton.module.css';
export default function ToDoItemActionButton({ onClick, icon }) {
	return <button onClick={onClick} className={styles.item__actionsButton}></button>;
}
